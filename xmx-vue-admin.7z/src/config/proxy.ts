import { httpConfig, type Api, type Environment } from "./config.ts"
import type { ProxyOptions } from 'vite'

/**
 * 返回用于 Vite 配置的 proxy 对象
 */
export const createProxy = (): Record<string, ProxyOptions> => {
    const proxyObj: Record<string, ProxyOptions> = {}
    for (const env in httpConfig) {
        const envHttp = httpConfig[env as Environment]
        for (const key in envHttp) {
            if (Object.prototype.hasOwnProperty.call(envHttp, key)) {
                const { proxyPrefix, baseUrl } = envHttp[key as Api]
                proxyObj[proxyPrefix] = {
                    target: baseUrl,
                    changeOrigin: true,
                    rewrite: (path: string): string => {
                        console.log(`[代理重写] ${path} -> ${path.replace(new RegExp(`^${proxyPrefix}`), '')}`)
                        return path.replace(new RegExp(`^${proxyPrefix}`), '')
                    }
                }
            }
        }
    }
    console.table(proxyObj)
    return proxyObj
}
