
export type Api = "manage"

type HttpServiceConfig = {
    [key in Api]: {
        baseUrl: string
        proxyPrefix: string
    }
}
export type Environment = "dev" | "test" | "prod";
type HttpConfig = {
    [key in Environment]: HttpServiceConfig
}

export const httpConfig: HttpConfig = {
    dev: {
        manage: {
            baseUrl: 'http://localhost:3000',
            proxyPrefix: '/manage',
        }
    },
    test: {
        manage: {
            baseUrl: 'http://localhost:3000',
            proxyPrefix: '/manage',
        }
    },
    prod: {
        manage: {
            baseUrl: 'http://localhost:3000',
            proxyPrefix: '/manage',
        }
    }
}

export const getCurrentHttpConfig = () => {
    return httpConfig[process.env.CODE_ENV as Environment].manage.proxyPrefix
}


export const appConfig = {
    /**网站水印 */
    watermark: "XMX-admin",
    /**token key */
    tokenKey: "XMX",
    /** 网站名称 */
    websiteName: "XMX",
    /** 当前版本 */
    version: "1.0.0",
    /** 默认语言 */
    defaultLanguage: "zh-CN",
    /**路由白名单 */
    whiteList: [
        "/login",
        "/register"
    ]
}