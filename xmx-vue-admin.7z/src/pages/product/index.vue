<template>
    <div>
        product
    </div>
</template>

<script lang="ts" setup>
    onMounted(() => {
        console.log("产品管理")
    })
</script>

<style lang="scss" scoped></style>