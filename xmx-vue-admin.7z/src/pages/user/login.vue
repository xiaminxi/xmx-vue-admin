<template>
    <div class="app-container">
        登录页
    </div>
</template>

<script lang="ts" setup>

</script>

<style lang="scss" scoped>

    .app-container {
        width: 100%;
        height: 100vh;
        background-color: #fff;
    }
</style>