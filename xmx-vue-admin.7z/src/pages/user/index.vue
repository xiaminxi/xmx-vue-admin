<template>
    <div>
        user
    </div>
</template>

<script lang="ts" setup>
    defineOptions({ name: "User" })
    console.log("用户管理")

    onMounted(() => {
        console.log("🚀 ~ 用户管理:", "用户管理")

    })
</script>

<style lang="scss" scoped></style>