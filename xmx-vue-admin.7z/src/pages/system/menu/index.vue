<template>
    <div>
        <a-input v-model="value"></a-input>
    </div>
</template>

<script lang="ts" setup>

    defineOptions({ name: "Menu" })
    const value = ref()


</script>

<style lang="scss" scoped></style>