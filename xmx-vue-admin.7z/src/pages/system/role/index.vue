<template>
    <div>
        <a-input v-model="message"></a-input>
    </div>
</template>

<script lang="ts" setup>
    defineOptions({
        name: "Role"
    })
    onMounted(() => {
        console.log("角色管理")
    })

    const message = ref("")
</script>

<style lang="scss" scoped></style>