<template>
    <div>
        wer
        <a-input v-model="value"></a-input>
        <TestComponent>
            {{ status }}
            {{ state }}
        </TestComponent>
    </div>
</template>

<script lang="ts" setup name="Index">
    import TestComponent from '@/components/TestComponent/TestComponent.vue';
    import useTestHook from '@/hook/useTestHook/useTestHook';

    const { status, changeStatus: change } = useTestHook(0)
    const { status: state, changeStatus: open } = useTestHook(0)
    setTimeout(() => {
        change(3000)
    }, 3000);
    setTimeout(() => {
        open(6000)
    }, 6000);

    defineOptions({
        name: "Index"
    })
    const value = ref()

    console.log(process);

    onMounted(() => {

    })
</script>

<style lang="scss" scoped></style>