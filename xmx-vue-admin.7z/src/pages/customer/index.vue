<template>
    <div>
        customer
    </div>
</template>

<script lang="ts" setup>

</script>

<style lang="scss" scoped>


</style>