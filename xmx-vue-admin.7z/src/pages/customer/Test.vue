<script>


  export default defineComponent({
    name: 'Menu',
    setup() {
      return () => (
        <div>
          Menu 页面
        </div>
      )
    }
  })

</script>