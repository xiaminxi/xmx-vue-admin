
interface TabItem {
    path: string
    name: string
    index: number
    title: string
    refresh: boolean
    keepAlive: boolean
}
interface UseRouteStore {
    activeKey: string
    tabsList: TabItem[]
    cacheView: string[]
    refreshFlag: Record<string, Boolean>
}