import { defineStore } from "pinia";
import type { RouteLocationNormalizedLoaded } from 'vue-router'
import routerInstance from "../router/index";
import useSleep from "@/hook/useSleep";
const { sleep } = useSleep()


const useRouteStore = defineStore("useRouteStore", {
    state: (): UseRouteStore => {
        return {
            tabsList: [
                { title: "首页", path: "/index", name: "Index", index: 0, refresh: false, keepAlive: true }
            ],
            activeKey: null as unknown as string,
            cacheView: ["Index"],
            refreshFlag: {},
        }
    },
    getters: {
        getRefreshStatus() {
            return (path: string) => {
                console.log("🚀 ~ path:", path)
                const result = this.tabsList.find(item => item.path === path)
                return result?.refresh ?? true
            }
        }
    },
    actions: {
        setActiveKey(activeKey: string) {
            this.activeKey = activeKey
        },
        /**缓存keep-alive */
        insertCacheView(route: RouteLocationNormalizedLoaded) {
            if (route.meta.keepAlive && route.name && !this.cacheView.includes(route.name as string)) {
                this.cacheView.push(route.name as string)
            }
        },
        /**删除缓存keep-alive */
        deleteCacheView(cacheName: string) {
            this.cacheView = this.cacheView.filter(item => item !== cacheName)
        },
        /**添加路由 */
        async insertTab(route: RouteLocationNormalizedLoaded) {
            console.log("🚀 ~ addTab ~ route:", route)
            if (!this.tabsList.find(tab => tab.path === route.fullPath)) {
                this.tabsList.push({
                    refresh: true,
                    path: route.fullPath,
                    index: this.tabsList.length,
                    name: route?.name as string,
                    title: route.meta.title as string,
                    keepAlive: route.meta.keepAlive ?? false,
                })
                this.insertCacheView(route)
            }
            this.activeKey = route.fullPath
            await sleep(100)
            this.tabsList[this.tabsList.length - 1].refresh = false
        },
        /**获取下一个页签 */
        getNextTab(index: number) {
            return this.tabsList?.[index + 1] ?? this.tabsList[index - 1]
        },
        /**关闭当前 */
        closeCurrentTab(current: TabItem, index: number) {
            const { path, name } = current
            if (this.activeKey === path) {
                const nextTab = this.getNextTab(index)
                this.activeKey = nextTab.path
                routerInstance.push({ path: nextTab.path })
            }
            this.tabsList = this.tabsList.filter(item => item.path !== current.path)
            this.deleteCacheView(name)
        },
        /**关闭其他 */
        closeOthersTab(current: TabItem) {
            if (this.tabsList.length === 2) return false
            this.tabsList.forEach(item => {
                if (item.name !== current.name) {
                    this.deleteCacheView(item.name)
                }
            })
            this.tabsList = this.tabsList.filter(item => item.path === current.path || item.index === 0)
            this.activeKey = current.path
            routerInstance.push({ path: current.path })
        },
        /**关闭全部 */
        closeAllTabs() {
            if (this.tabsList.length === 1) return false
            this.tabsList.forEach(item => {
                if (item.index !== 0) {
                    this.deleteCacheView(item.name)
                }
            })
            const [onlyOne] = this.tabsList = this.tabsList.filter(item => item.index === 0)
            this.activeKey = onlyOne.path
            routerInstance.push({ path: onlyOne.path })
        },
        /**刷新当前页 */
        async refreshCurrentTab(current: TabItem) {
            current.refresh = true
            if (current.keepAlive) {
                this.cacheView = this.cacheView.filter(name => name !== current.name)
            }
            // 刷新的等待时间
            await sleep(500)
            if (current.keepAlive) {
                this.cacheView.push(current.name)
            }
            current.refresh = false
        },
        /**点击标签页的下拉菜单 */
        dropdownMenuClick(event: { key: string }, current: TabItem, index: number) {
            console.log("🚀 ~ key:", event.key)
            switch (event.key) {
                case "closeCurrent":
                    return this.closeCurrentTab(current, index)
                case "refresh":
                    return this.refreshCurrentTab(current)
                case "closeOthers":
                    return this.closeOthersTab(current)
                case "closeAll":
                    return this.closeAllTabs()
            }
        },

    },
    persist: true
})

export default useRouteStore