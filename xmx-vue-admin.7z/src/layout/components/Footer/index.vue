<template>
    <div class="footer">
        dibu
    </div>
</template>

<script lang="ts" setup>

</script>

<style lang="scss" scoped>
    .footer {
        height: 40px;
        border: 1px solid red;
    }
</style>