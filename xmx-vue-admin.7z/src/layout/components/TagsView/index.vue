<template>

    <ScrollView :activeKey="activeKey">
        <template v-for="(item, tabIndex) in tabsList" :key="item.path">
            <a-dropdown :trigger="['contextmenu']" placement="bottom" :arrow="{ pointAtCenter: true }">
                <a-button class="tags-button" :data-key="item.path" :class="changeClass(item)" @click="clickTabgsButton(item.path)">
                    <span>{{ item.title }}</span>
                    <CloseOutlined v-if="item.path !== '/index'" @click.passive="deleteCurrentTab(item, tabIndex)" />
                </a-button>

                <template #overlay>
                    <a-menu @click="dropdownMenuClick($event, item, tabIndex)">
                        <a-menu-item v-for="menu in tabMenuItems" :key="menu.key">
                            <div class="menu-item-content">
                                <component :is="menu.icon" />
                                <span class="content-span">{{ menu.label }}</span>
                            </div>
                        </a-menu-item>
                    </a-menu>
                </template>
            </a-dropdown>
        </template>
    </ScrollView>

</template>

<script lang="ts" setup>
    import useRouteStore from '@/modules/useRouteStore';
    import { CloseOutlined, ReloadOutlined, CloseCircleOutlined, CloseSquareOutlined, FullscreenOutlined } from '@ant-design/icons-vue';
    import ScrollView from "@/components/ScrollView/index.vue"
    const router = useRouter()
    const routeStore = useRouteStore()


    const { activeKey, tabsList } = storeToRefs(routeStore)
    const { dropdownMenuClick, deleteCurrentTab } = routeStore

    const changeClass = (item: TabItem) => {
        return item.path === activeKey.value ? "active-tag" : ""
    }
    const tabMenuItems = [
        {
            key: 'refresh',
            icon: ReloadOutlined,
            label: '刷新页面'
        },
        {
            key: 'closeCurrent',
            icon: CloseOutlined,
            label: '关闭当前'
        },
        {
            key: 'closeOthers',
            icon: CloseCircleOutlined,
            label: '关闭其他'
        },
        {
            key: 'closeAll',
            icon: CloseSquareOutlined,
            label: '关闭全部'
        }
    ];


    const clickTabgsButton = (path: string) => {
        activeKey.value = path
        router.push({ path })
    }


</script>

<style lang="scss" scoped>
    .tags-button {
        border-radius: 0px;
    }

    .active-tag {
        color: $primary;
        border-color: #1677ff;
    }


    .dropdown-menu-item {
        display: flex;

        .dropdown-menu-item-label {
            margin-right: 12px;
        }
    }

    .menu-item-content {
        color: $gray-6;

        &:hover {
            color: $gray-9;
        }

        .content-span {
            margin-left: 12px;
        }
    }

</style>