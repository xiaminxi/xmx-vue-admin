<template>
    <div class="loading-wrap">
        <a-spin>
            <template #indicator>
                <LoadingOutlined style="font-size: 32px;" />
            </template>
        </a-spin>
    </div>
</template>

<script lang="ts" setup>
    import { LoadingOutlined } from '@ant-design/icons-vue';

</script>

<style lang="scss" scoped>
    .loading-wrap {
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
    }
</style>