<template>
    <div class="content">
        <router-view v-slot="{ Component, route }">
            <KeepAlive :include="cacheView">
                <component v-if="!getRefreshStatus(route.fullPath)" :is="Component" :key="route.path" />
                <Refresh v-else />
            </KeepAlive>
        </router-view>
    </div>
</template>

<script lang="ts" setup>
    import useRouteStore from '@/modules/useRouteStore';
    import Refresh from '../Refresh/Refresh.vue';
    const routeStore = useRouteStore()
    const { cacheView, getRefreshStatus } = storeToRefs(routeStore)

</script>

<style lang="scss" scoped>
    .content {
        flex: 1;
        padding: 20px;
    }
</style>