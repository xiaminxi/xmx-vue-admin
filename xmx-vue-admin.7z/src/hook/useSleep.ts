function useSleep() {
    const timerIdSet = ref<Set<NodeJS.Timeout>>(new Set())
    const sleep = async (delay: number = 500): Promise<void> => {
        return new Promise((resolve) => {
            const timerId = setTimeout(() => {
                timerIdSet.value.delete(timerId)
                resolve()
            }, delay)
            timerIdSet.value.add(timerId)
        })
    }

    onUnmounted(() => {
        timerIdSet.value.forEach(timerId => {
            clearTimeout(timerId)
        })
        timerIdSet.value.clear()
    })

    return {
        sleep
    }
}

export default useSleep