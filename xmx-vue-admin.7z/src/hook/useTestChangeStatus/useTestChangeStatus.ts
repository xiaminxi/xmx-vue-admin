
interface UseTestChangeStatus {
    intervalTime?: number
    statusList: string[] | number[]
}

const useTestChangeStatus = (props: UseTestChangeStatus) => {
    const { statusList, intervalTime = 1000 } = props
    const timer = ref<NodeJS.Timeout | null>()
    const changeStatus = (callback: (status: string | number) => void) => {
        let index = 0
        // 立即执行一次
        callback(statusList[index])
        clearIntervalTimerId()

        // 设置定时器
        timer.value = setInterval(() => {
            index = (index + 1) % statusList.length
            callback(statusList[index])
        }, intervalTime)
    }

    const clearIntervalTimerId = () => {
        if (timer.value) {
            clearInterval(timer.value)
        }
    }

    onUnmounted(() => {
        clearIntervalTimerId()
    })

    return {
        changeStatus: changeStatus,
        clear: clearIntervalTimerId
    }
}

export default useTestChangeStatus