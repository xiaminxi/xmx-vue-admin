const useTestHook = <T = any>(defaultValue: T) => {
    const status = ref<T>(defaultValue)

    const changeStatus = (val: T) => {
        status.value = val
    }

    return {
        status,
        changeStatus
    }
}

export default useTestHook