<template>
    <div class="message-box">
        <slot></slot>
    </div>
</template>

<script lang="ts" setup>

    onMounted(() => {

    })
</script>

<style lang="scss" scoped>

    .message-box {
        font-size: 36px;
        font-weight: bold;
        width: 400px;
        height: 200px;
        border: 1px solid black;
        color: black;


        display: flex;
        align-items: center;
        justify-content: center;
    }
</style>